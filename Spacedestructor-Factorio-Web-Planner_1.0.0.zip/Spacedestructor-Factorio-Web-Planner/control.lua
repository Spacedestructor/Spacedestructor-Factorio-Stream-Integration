--require "std.io"
--Dumps Data in to Files.
local function write(File_Name, Data)
	local File_Path = "spacedestructor/FWP/"
	local Player_Index = gui.player.index
	local Path = File_Path .. File_Name
	game.write_file(Path, Data, false, Player_Index)
end

--local function ScanDirectory() local directory = [["%APPDATA%\Factorio\script-output\spacedestructor\FWP"]], i, t, popen = 0, {}, io.popen local pfile = popen('dir "'..directory..'" /b ') for filename in pfile:lines() do i = i + 1 t[i] = filename end pfile:close() return t end local test = ScanDirectory()
local some_unused_var_to_prevent_feeding_comments_in_to_wrong_places
--This whole section has been commented out due to Factorio being a Pain to add libraries too in a mod if your unable to upload them to the mod Portal.
--"/ad" can be used to specifie only directories, /b can be used to specifie only filenames.
--local function ScanDirectory() local files = {} for dir in io.popen([[dir "%APPDATA%\Factorio\script-output\spacedestructor\FWP" /b]]):lines() do table.insert(files, dir) end return files end
--local function DeleteFiles() local files = ScanDirectory() for key, value in pairs(files) do local Full_Path = "spacedestructor/FWP/" .. value game.remove_Path(Full_Path) end print('Deleted all Files in "%APPDATA%/Factorio/script-output/spacedestructor/FWP"!') end
--DeleteFiles()

local Recipe_File_Name = "Recipe.json"
local Recipe_Table = {game.forces["player"].recipes}
local Recipe_Json = game.table_to_json(Recipe_Table)
game.print(Recipe_Json)
write(Recipe_File_Name, Recipe_Json) --Dumps All Recipes

local Item_File_Name = "Item.json"
local Item_Table = {game.item_prototypes}
local Item_Json = game.table_to_json(Item_Table)
game.print(Item_Json)
write(Item_File_Name, Item_Json) --Dumps All Items

local Entity_File_Name = "Entity.json"
local Entity_Table = {game.entity_prototypes}
local Entity_Json = game.table_to_json(Entity_Table)
game.print(Entity_Json)
write(Entity_File_Name, Entity_Json) --Dumps All Entities

local Equipment_File_Name = "Equipment.json"
local Equipment_Table = {game.equipment_prototypes}
local Equipment_Json = game.table_to_json(Equipment_Table)
game.print(Equipment_Json)
write(Equipment_File_Name, Equipment_Json) --Dumps All Equipment

local Fluid_File_Name = "Fluid.json"
local Fluid_Table = {game.fluid_prototypes}
local Fluid_Json = game.table_to_json(Fluid_Table)
game.print(Fluid_Json)
write(Fluid_File_Name, Fluid_Json) --Dumps All Fluid

local Tile_File_Name = "Tile.json"
local Tile_Table = {game.tile_prototypes}
local Tile_Json = game.table_to_json(Tile_Table)
game.print(Tile_Json)
write(Tile_File_Name, Tile_Json) --Dumps All Tiles

local Technology_File_Name = "Technology.json"
local Technology_Table = {game.technology_prototypes}
local Technology_Json = game.table_to_json(Technology_Table)
game.print(Technology_Json)
write(Technology_File_Name, Technology_Json) --Dumps All Technology

local Module_File_Name = "Module.json"
local Module_Table = {game.get_filtered_item_prototypes{{filter = "type", type = "module"}}}
local Module_Json = game.table_to_json(Module_Table)
game.print(Module_Json)
write(Module_File_Name, Module_Json) --Dumps All Modules